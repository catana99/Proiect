#ifndef BAZE_DE_DATE_H
#define BAZE_DE_DATE_H
#include "Person.h"
#include <bits/stdc++.h>

class Baze_de_date : public Person {
private:
    vector<Person *> list_person;
    unsigned int nr_of_people;
public:
    Baze_de_date() {
        nr_of_people = 0;
    }
    ~Baze_de_date();
    void addPerson(string _name, unsigned int _birth_year, char _sex);
    void delPerson(string _name);
    void delPerson(unsigned int _birth_year);
    void delPerson(char _sex);
    void showAlphabetically();
    void showAscByAge();
};


#endif // BAZE_DE_DATE_H
