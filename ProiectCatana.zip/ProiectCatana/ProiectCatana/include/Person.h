#ifndef PERSON_H
#define PERSON_H

#include <bits/stdc++.h>
using namespace std;

class Person {
private:
    string name;
    unsigned int birth_year;
    char sex;
public:
    void setName(string name) {
        this->name = name;
    }
    void setBirthYear(unsigned int year) {
        birth_year = year;
    }
    void setGender(char g) {
        sex = g;
    }
    string getName() {
        return name;
    }
    unsigned int getBirthYear() {
        return birth_year;
    }
    char getGender() {
        return sex;
    }
};

#endif // PERSON_H
