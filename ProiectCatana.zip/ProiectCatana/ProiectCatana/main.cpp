#include <iostream>
#include <bits/stdc++.h>
#include <conio.h>
#include "Baze_de_date.h"

int main()
{
    Baze_de_date data;
    bool running = true;
    int option;
    string name;
    char gender;
    unsigned int year;
    while(running)
    {
        cout<<"Selectati optiunea dorita : "<<endl;
        cout<<"1. Adaugati Persoana"<<endl;
        cout<<"2. Stergeti Persoana"<<endl;
        cout<<"3. Afisati lista de persoane de baza de date"<<endl;
        cout<<"4. Iesiti"<<endl;
        cout<<">>";
        do{
            cin>>option;
            if(option < 0|| option >= 5) cout<<"Optiune gresita!!";
        }while(option < 0|| option >= 5);
        system("cls");
        switch (option)
        {
        case 1:
        {
            cout<<"Introduceti date persoana: "<<endl;
            cin>>name>>year>>gender;
            data.addPerson(name, year, gender);
            system("cls");
            break;
        }
        case 2:
        {
            cout<<"Cum vreti sa stergeti persoana ?"<<endl;
            cout<<"1. Dupa nume"<<endl;
            cout<<"2. Dupa an"<<endl;
            cout<<"3. Dupa sex"<<endl;
            cin>>option;
            do
            {
                switch(option)
                {
                case 1:
                {
                    cin>>name;
                    data.delPerson(name);
                    break;
                }
                case 2:
                {
                    cin>>year;
                    data.delPerson(year);
                    break;
                }
                case 3:
                {
                    cin>>gender;
                    data.delPerson(gender);
                    break;
                }
                default :{cout<<"Optiune gresita"; cin>>option;
                system("cls");option = -1;}
                }
                break;
            }
            while(option == -1);
            break;
        }
        case 3:
        {
            cout<<"Cum vreti sa se afiseze lista ?"<<endl;
            cout<<"1.Ordonat dupa nume"<<endl;
            cout<<"2.Ordonat dupa an"<<endl;
            cin>>option;
               do
            {
                switch(option)
                {
                case 1:
                {
                    data.showAlphabetically();
                    break;
                }
                case 2:
                {
                    data.showAscByAge();
                    break;
                }
                default:
                {
                    cout<<"Optiune gresita !!!";
                    cin>>option;
                    system("cls");
                    break;
                    option=-1;
                }
                }
            }
            while(option == -1);
            break;
            }
        case 4: {running = false; break;}
        }
    }
    return 0;
}
