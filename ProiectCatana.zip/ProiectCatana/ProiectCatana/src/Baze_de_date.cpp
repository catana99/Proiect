#include "Baze_de_date.h"

struct comparePersonAlphabetically {
    bool operator ()(Person *p1, Person *p2) {
        string c1 = p1->getName();
        string c2 = p2->getName();
        return c1.compare(c2) < 0;
    }
}comp1;

struct comparePersonByBirthYear {
    bool operator ()(Person *p1, Person *p2){
        unsigned int c1 = p1->getBirthYear();
        unsigned int c2 = p2->getBirthYear();
        return c1 < c2;
    }
}comp2;

void Baze_de_date::addPerson(string _name, unsigned int _birth_year, char _sex) {
    Person *p = new Person();
    p->setName(_name);
    p->setBirthYear(_birth_year);
    p->setGender(_sex);
    list_person.push_back(p);
    nr_of_people++;
}

void Baze_de_date::delPerson(string _name) {
    for(std::vector<Person *>::iterator it = list_person.begin(); it != list_person.end(); ++it) {
        if((*it)->getName() == _name) {
            delete *it;
            list_person.erase(it);
            --it;
        }
    }
}

void Baze_de_date::delPerson(unsigned int _birth_year) {
    for(std::vector<Person *>::iterator it = list_person.begin(); it != list_person.end(); ++it) {
        if((*it)->getBirthYear() == _birth_year) {
            delete *it;
            list_person.erase(it);
            --it;
        }
    }
}

void Baze_de_date::delPerson(char _sex) {
    for(std::vector<Person *>::iterator it = list_person.begin(); it != list_person.end(); ++it) {
        if((*it)->getGender() == _sex) {
            delete *it;
            list_person.erase(it);
            --it;
        }
    }
}

Baze_de_date::~Baze_de_date() {
    if(nr_of_people != 0) {
        vector<Person *>::iterator it = list_person.begin();
        Person *cur;
        for(; it != list_person.end(); ++it) {
            cur = *it;
            delete cur;
        }
        list_person.clear();
    }
}

void Baze_de_date::showAlphabetically() {
    vector<Person *> temp;
    temp.assign(list_person.begin(), list_person.end());
    sort(temp.begin(), temp.end(), comp1);
    for(std::vector<Person *>::iterator it = temp.begin(); it != temp.end(); ++it)
        cout<<(*it)->getName()<<" "<<(*it)->getBirthYear()<<" "<<(*it)->getGender()<<" "<<endl;
    cout<<endl;
}

void Baze_de_date::showAscByAge() {
    vector<Person *> temp;
    temp.assign(list_person.begin(), list_person.end());
    sort(temp.begin(), temp.end(), comp2);
    for(std::vector<Person *>::iterator it = temp.begin(); it != temp.end(); ++it)
        cout<<(*it)->getName()<<" "<<(*it)->getBirthYear()<<" "<<(*it)->getGender()<<" "<<endl;
    cout<<endl;
}
